from PIL import Image, ImageDraw, ImageFont
import os

sizes = [192, 512]
for size in sizes:
    img = Image.new('RGB', (size, size), '#009b4d')
    draw = ImageDraw.Draw(img)
    
    # Yellow circle
    pad = size * 0.12
    draw.ellipse([pad, pad, size-pad, size-pad], fill='#ffd100')
    
    # BP text
    font_size = int(size * 0.38)
    try:
        font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', font_size)
    except:
        font = ImageFont.load_default()
    
    text = 'bp'
    bbox = draw.textbbox((0,0), text, font=font)
    tw = bbox[2]-bbox[0]
    th = bbox[3]-bbox[1]
    x = (size - tw) / 2
    y = (size - th) / 2 - bbox[1]
    draw.text((x, y), text, fill='#009b4d', font=font)
    
    img.save(f'/home/claude/bp-pwa/icon-{size}.png')
    print(f'Created icon-{size}.png')

